//import classes
import javax.swing.*;
import java.util.Random;



public class Asteroid {

	//declare variables
	Random rnd = new Random();
	Spaceship ship = new Spaceship();
	private ImageIcon imgAsteroid, imgExplosion;
	private int x, y, rndX, rndY;
	private int spawnLocationsX [], spawnLocationsY [];
		
	public Asteroid()
	{
		
		//initialize variables
		spawnLocationsX = new int [] {0, 200, 300, 400, 600, 800, 900, 1000, 1260};
		spawnLocationsY = new int [] {-120, 713};
		rndX = rnd.nextInt(9);
		rndY = rnd.nextInt(2);
		x = spawnLocationsX[rndX];
		y = spawnLocationsY[rndY];
		imgAsteroid = new ImageIcon("asteroid.png");
		imgExplosion = new ImageIcon("explosion.png");
	}
	
	//makes asteroid follow player
	public void move(int shipX, int shipY)
	{
		if (x < shipX)
		{
			x += 5;
		}
		
		if (x > shipX)
		{
			x -= 5;
		}
		
		if (y < shipY)
		{
			y += 5;
		}
		
		if (y > shipY)
		{
			y -= 5;
		}
	}
	
	//spawns the asteroid in a random position specified
	public void spawn ()
	{
	
		x = spawnLocationsX[rndX];
		y = spawnLocationsY[rndY];
	}
	
	//returns the image icon of the asteroid
	public ImageIcon getImage()
	{
		return imgAsteroid;
	}
	
	//returns the x position of the asteroid
	public int getX()
	{
		return x;
	}
	
	//returns the y position of the asteroid
	public int getY()
	{
		return y;
	}
	
	//returns the width of the asteroid image icon
	public int getWidth()
	{
		return imgAsteroid.getIconWidth();
	}
	
	//returns the height of the asteroid image icon
	public int getHeight()
	{
		return imgAsteroid.getIconHeight();
	}
	
	//returns the explosion image icon
	public ImageIcon explosion()
	{
		return imgExplosion;
	}
	
}
