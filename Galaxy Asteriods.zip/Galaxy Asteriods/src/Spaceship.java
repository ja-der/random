//import classes
import javax.swing.*;

public class Spaceship {
	
	//declare variables
	private int x, y, panelHeight, panelWidth, direction;
	final private int LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4;
	private ImageIcon imgShip;
	
	public Spaceship ()
	{
		//initialize variables
		x = 1100;
		y = 350;
		panelHeight = 703;
		panelWidth = 1250;
		imgShip = new ImageIcon("spaceship.png");
	}
	
	//returns x position of the ship
	public int getX()
	{
		return x;
	}
	
	//returns y postition of the ship
	public int getY()
	{
		return y;
	}
	
	//moves this ship right
	public void moveRight()
	{
		if (x + imgShip.getIconWidth() >= panelWidth)
		{
			x += 0;
		}
		else
		{
			x += 10;
		}
	}
	
	//moves the ship left
	public void moveLeft()
	{		
		if ( x <= 0)
		{
			x -= 0;
		}
		else
		{
			x -= 10;
		}
		
	}
	
	//moves the ship up
	public void moveUp()
	{
		
		if (y <= 0)
		{
			y -= 0;
		}
		else
		{
			y -= 10;
		}
		
	}
	
	//moves the ship down
	public void moveDown()
	{
		
		if (y + imgShip.getIconHeight()  >= panelHeight)
		{
			y += 0;
		}
		else 
		{
			y += 10;
		}
		
	}
	
	//returns the width of the ship
	public int getWidth()
	{
		return imgShip.getIconWidth();
	}
	
	//returns the height of the ship
	public int getHeight()
	{
		return imgShip.getIconHeight();
	}
	
	//returns the image icon of the ship depending on the direction it is moving in
	public ImageIcon getImage(int direction)
	{
		if (direction == UP)
		{
			imgShip = new ImageIcon ("spaceship.png");
		}
		else if (direction == DOWN)
		{
			imgShip = new ImageIcon ("spaceshipDown.png");
		}
		else if (direction == RIGHT)
		{
			imgShip = new ImageIcon("spaceshipRight.png");
		}
		else if (direction == LEFT)
		{
			imgShip = new ImageIcon("spaceshipLeft.png");
		}
		return imgShip;
	}
	


}
