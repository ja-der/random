/*
 * ICS 3U1 CPT: INTERSTELLAR ASSAULT
 * Name: Jason Der
 * Program Description: This is a space themed game that involves a couple of mini games that the player must over come. The first is a guessing game in which the player must unscramble letters of the word and guess 
 * it correctly in order to advance. Afterwards, the player moves on to the main game with a story mode. The player will see cutscenes and message panels that help progress the story. 
 * Then, the player will have to complete a series of riddles and get them all correct before advancing furthur. Next, the player will come across a room with asteroids.
 *  The goal is to shoot enough asteroids to progress. The asteroids will chase after the player and will respawn constantly. The player cannot leave the room. 
 *  Shooting at the asteroids will result in their destruction, with a explosion animation. Note that there is no bullet penetration so the bullet is destroyed when it collides 
 *  with an asteroid. After shooting enough asteroids, the player will then have to fight against both asteroids and comets. Comets are different in which when they are destroyed, 
 *  they do not show an explosion as they disintegrate instantly, also, when they are destroyed, a new one spawns in randomly in the room. Therefore the player must pay attention. 
 *  The player also has hidden lives, a total of five. Colliding with an asteroid or a comet will lead to subtracting one of their lives. When the player has shot enough asteroids 
 *  and comets, the player will have won the game and will be brought back to start 
 * 
 * Program Details: In this program, there have been numerous methods as well as classes used . There is a separate class for the major elements of the game. This means that the 
 * spaceship, the asteroids, the beacons, and etc each have their own class in order to make the code neat and modularized. All of the component's functions are embedded into 
 * their respective class.  There are 5 classes of the asteroid to keep track of each on separately. Try catch statements have been used in areas where input is asked for in 
 * order to prevent the program from crashing. Loops and if statements have been used a lot in the program especially in the first and second minigame where the player must 
 * guess the answer correctly. These run until the player guesses them correctly. The string class has been used in the riddle class where it compares the player's guess with
 *  the correct answer. To create buttons, the mouse listener class was used to check if the player uses the mouse to click within the boundaries of the button. Finally, numerous 
 *  timers were used in the game to get things to move and act automatically after the timer was started. These timers are good for infinite events and events that need to run only 
 *  for a specific amount of time
 */



//import classes
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

//extend Jpanel and implement listeners
public class Main extends JPanel implements ActionListener, KeyListener, MouseListener{

	//set up objects that point to different classes
	JFrame frame = new JFrame();
	Bullet bullet = new Bullet();
	Spaceship ship = new Spaceship();
	Asteroid asteroid = new Asteroid();
	Asteroid2 asteroid2 = new Asteroid2();
	Asteroid3 asteroid3 = new Asteroid3();
	Asteroid4 asteroid4 = new Asteroid4();
	Asteroid5 asteroid5 = new Asteroid5();
	Beacon beacon = new Beacon();
	
	//declare all variables
	final private int LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4;
	final private int TRUE = 1, FALSE = 2;
	final private int SPAWNED = 1, NOTSPAWNED = 2; 
	private Timer bulletTimer, asteroidTimer, asteroidTimer2, asteroidTimer3, asteroidTimer4, asteroidTimer5, asteroidSpawner, explosionTimer, explosionTimer2, explosionTimer3,explosionTimer4, explosionTimer5,  gameEnd, cometTimer, transition1;
	private boolean spawn, result1;
	private int direction, bulletDirection, hitCounter, lastHit, asteroid1State, asteroid2State, asteroid3State, asteroid4State, asteroid5State, score, transition1X, collide, collide2, collide3, collide4, collide5, cometX[], cometY[], rndX, rndY, lastCollide[], rndCollide;
	private Rectangle2D shipMask, beacon1Mask, beacon2Mask, beacon3Mask, beacon4Mask, bulletMask;
	private Ellipse2D asteroidMask, asteroidMask2, asteroidMask3, asteroidMask4, asteroidMask5,  cometMask[];
	private ImageIcon loadingPage, title, startPage, cutscene1, background, comet[], startButton, helpButton, imgHouston, imgYou, imgTransition1, puzzle; 
	private String name;
	private static Timer intermission, roomAdvance;
	static int roomNumber, index, room;
	static String word, letters [], guess, scrambled[];
	static boolean stop, complete, verdict;



	//initialize all variables
	public Main()
	{
		//setup random
		Random rnd = new Random();

		//initialize images
		loadingPage = new ImageIcon ("loadingPage.png");
		startPage = new ImageIcon ("startMenu.jpg");
		cutscene1 = new ImageIcon ("cutscene1.jpg");
		background = new ImageIcon ("background.jpg");
		title = new ImageIcon("Game Poster.png");
		startButton = new ImageIcon ("startButton.png");
		helpButton = new ImageIcon ("helpButton.png");
		imgHouston = new ImageIcon("Houston.jpg");
		imgYou = new ImageIcon("spaceship.png");
		imgTransition1 = new ImageIcon("spaceshipRight.png");
		puzzle = new ImageIcon("puzzle.jpg");
		
		//initialize comet arrays
		comet = new ImageIcon [10];
		cometX = new int [10];
		cometY = new int [10];
		lastCollide = new int [10];
		cometMask = new Ellipse2D[10];
		
		//fill in comet arrays
		for (int i = 0; i < 10; i ++)
		{
			comet[i] = new ImageIcon("meteor.png");	
			rndX = rnd.nextInt(1250);
			rndY = rnd.nextInt(703);
			rndCollide = rnd.nextInt(4) + 1;
			lastCollide[i] = rndCollide;

			cometX[i] = rndX;
			cometY[i] = rndY;
			cometMask[i] = new Ellipse2D.Double(-100,-100,-100,-100);
		}
		
	
		//initialize variables
		room = 1;
		roomNumber = 0;
		word = "petropavlovsk";
		letters = new String [word.length()];
		scrambled = new String[word.length()];
		stop = false;
		complete = false;
		verdict = false;
		
		//set initial values of variables
		name = "";
		score = 0;
		spawn = false;
		direction = UP;
		lastHit = UP;
		hitCounter = 0;
		transition1X = 0;
		
		//sets all asteroid collisions to false
		collide = FALSE;
		collide2 = FALSE;
		collide3 = FALSE;
		collide4 = FALSE;
		collide5 = FALSE;

		//sets the state of all asteroids to not spawned yet
		asteroid1State = NOTSPAWNED;
		asteroid2State = NOTSPAWNED;
		asteroid3State = NOTSPAWNED;
		asteroid4State = NOTSPAWNED;
		asteroid5State = NOTSPAWNED;
		
		//setup key listener class
		setLayout(null);
		addKeyListener(this);
		setFocusable(true);
		requestFocus();
		
		addMouseListener(this);
		
		//setup the JPanel class
		frame.setContentPane(this);
		frame.setTitle("Galaxy");
		frame.setSize(1000, 1000);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(this);
		frame.setVisible(true);
		

		//setup timers
		roomAdvance = new Timer(3000, this);
		bulletTimer = new Timer(100, this);
		asteroidSpawner = new Timer(500, this);
		intermission = new Timer(2000, this);
		gameEnd = new Timer(100, this);
		cometTimer = new Timer(100, this);
		transition1 = new Timer(100, this);

		//setup all asteroid timers
		asteroidTimer = new Timer(100, this);
		asteroidTimer2 = new Timer(100, this);
		asteroidTimer3 = new Timer(100, this);
		asteroidTimer4 = new Timer(100, this);
		asteroidTimer5 = new Timer (100, this);

		
		//setup all timers for asteroid explosions
		explosionTimer= new Timer(1000, this);
		explosionTimer2= new Timer(1000, this);
		explosionTimer3= new Timer(1000, this);
		explosionTimer4= new Timer(1000, this);
		explosionTimer5= new Timer(1000, this);

		//setup up masks for all components of the game
		bulletMask = new Rectangle2D.Double(bullet.getX(), bullet.getY(), bullet.getImage().getIconWidth(), bullet.getImage().getIconHeight());
		shipMask = new Rectangle2D.Double(ship.getX() + 25, ship.getY() + 45, ship.getWidth() - 50, ship.getHeight() - 70);
		asteroidMask = new Ellipse2D.Double(asteroid.getX(), asteroid.getY(), asteroid.getWidth(), asteroid.getHeight());
		asteroidMask2 = new Ellipse2D.Double(asteroid2.getX(), asteroid2.getY(), asteroid2.getWidth(), asteroid2.getHeight());
		asteroidMask3 = new Ellipse2D.Double(asteroid3.getX(), asteroid3.getY(), asteroid3.getWidth(), asteroid3.getHeight());
		asteroidMask4 = new Ellipse2D.Double(asteroid4.getX(), asteroid4.getY(), asteroid4.getWidth(), asteroid4.getHeight());
		asteroidMask5 = new Ellipse2D.Double(asteroid5.getX(), asteroid5.getY(), asteroid5.getWidth(), asteroid5.getHeight());


	}
	
	public static void main(String[] args) 
	{
		//bring user to console game
		System.out.println("Although this may seem unorthodoxed, in order to play this game, you must complete the first puzzle.Only the worthy are permitted!\n");
		new Main();
		complete = Main.guessGame();
		
		if (verdict == true)
		{
			intermission.start();
		}
		
	}
	
	//game randomizes order of letters and then asks the user for his or her guess
	public static boolean guessGame()
	{
		//set up classes
		Random rnd = new Random();
		Scanner input = new Scanner(System.in);
		

		if (room == 1)
		{
			//displays a message
			System.out.print("You have to unscramble the word provided to proceed\n");
			
			//scrambles the word
			for (int i = 0; i < word.length(); i ++)
			{
				letters [i] = word.substring(i, i + 1);
				
			}
			
			for (int j = 12; j >= 0; j --)
			{
				scrambled [j] = letters [j];
				System.out.print(scrambled[j]);

			}
			
			//prompt the user for input
			do 
			{
				System.out.print("\nEnter your guess here: ");
				guess = input.next();
				
				//if it is correct, moves on to the next room
				if (guess.equalsIgnoreCase(word))
				{
					System.out.println("Congrats, you got it right. You can head back to the game to continue your journey!");
					room ++;
					intermission.start();
					verdict = true;
					break;
				}
				
				//if guess is not correct, prompt the user to try again
				else 
				{
					System.out.println("That is incorrect please try again");
				}
			}
			while (1 != 2);
		}
		roomAdvance.start();

		//Returns true to main to start the game
		return verdict;
	}
	public void keyPressed(KeyEvent e)
	{
		//checks if start pages are over before allowing the player to move
		if (room >= 5)
		{
			//moves the player up
			if (e.getKeyCode() == KeyEvent.VK_UP)
			{	
				shipMask = new Rectangle2D.Double(ship.getX() + 25, ship.getY() + 25, ship.getWidth() - 50, ship.getHeight() - 60);
				direction = UP;
				lastHit = UP;
				ship.moveUp();

			}
			
			//moves the player down
			else if (e.getKeyCode() == KeyEvent.VK_DOWN)
			{
				shipMask = new Rectangle2D.Double(ship.getX() + 25, ship.getY() + 35, ship.getWidth() - 50, ship.getHeight() - 65);
				direction = DOWN;
				lastHit = DOWN;
				ship.moveDown();
			}
			
			//moves the player right
			else if (e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				shipMask = new Rectangle2D.Double(ship.getX() + 30, ship.getY() + 25, ship.getWidth() - 60, ship.getHeight() - 45);
				direction = RIGHT;
				lastHit = RIGHT;
				ship.moveRight();

			}
			
			//moves the player left
			else if (e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				shipMask = new Rectangle2D.Double(ship.getX() + 25, ship.getY() + 25, ship.getWidth() - 60, ship.getHeight() - 50);
				direction = LEFT;
				lastHit = LEFT;
				ship.moveLeft();
			}
		
			//shoots a bullet when the spacebar is pressed depending on the last arrow key hit
			if (e.getKeyCode() == KeyEvent.VK_S)
			{
				if (spawn == false)
				{
					//changes spawn to true and makes bullet direction the last arrow key hit
					spawn = true;
					bulletDirection = lastHit;
					
					//moves bullet up if direction is up
					if (direction == UP)
					{
						bullet.spawnY(ship.getY());
						bullet.spawnX(ship.getX() + ship.getWidth()/2 - 5);
					}
					
					//moves bullet right
					else if (direction == RIGHT)
					{
						bullet.spawnY(ship.getY() + ship.getHeight() / 2 - 5);
						bullet.spawnX(ship.getX() + ship.getWidth());
					}
					
					//moves bullet left
					else if (direction == LEFT)
					{
						bullet.spawnY(ship.getY() + ship.getHeight() / 2 - 10);
						bullet.spawnX(ship.getX());
					}
					
					//moves bullet down
					else if (direction == DOWN)
					{
						bullet.spawnY(ship.getY() + ship.getHeight() - 10);
						bullet.spawnX(ship.getX() + ship.getWidth() /2 - 10);
					}
					
					//start the bullet timer to move the bullet and check for collisions
					bulletTimer.start();
				}
			}
			
			
		
		}
		
		// In the quiz room, check when the spaceship comes into contact with any of the beacons
		if (room == 6)
		{
			if (beacon1Mask.intersects(shipMask))
			{
				beacon.question(0);
			}
			else if (shipMask.intersects(beacon2Mask))
			{
				beacon.question(1);
			}
			else if (shipMask.intersects(beacon3Mask))
			{
				beacon.question(2);
			}
			else if (shipMask.intersects(beacon4Mask))
			{
				beacon.question(3);
			}
			
			//progress the game if the player answers all riddles correctly
			result1 = beacon.win();
			if (result1 == true)
			{
				//displays message panels to progress through the story
				JOptionPane.showMessageDialog(null, "Houston here. Well done " + name + ", the rader is back online!\nI'll make sure your recieve your reward when you get...\n...\n...\nTHUNDERING TYPHOONS!", "WELL DONE", JOptionPane.PLAIN_MESSAGE, imgHouston);
				JOptionPane.showMessageDialog(null, "Hmm, it looks like he disconnected, I wonder why?\n I think I should head back and check it out.", "Your Thoughts", JOptionPane.PLAIN_MESSAGE, imgYou);
			
				//moves to the next room
				room ++;
				roomEvent();
			}
		}
		repaint();
	}
	
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
	
	//timer events
	public void actionPerformed(ActionEvent e)
	{
		//setup random class
		Random rnd = new Random();
		
		//timer events for the comet timer
		if (e.getSource() == cometTimer)
		{
			//iterates through each element of the array
			for (int k = 0; k < 10; k++)
			{
				//checks to see if the comet collides with the border and sets that side as the last side hit
				if (cometX[k] <= 0)
				{
					lastCollide[k] = LEFT;
				}
				else if  (cometX[k] + comet[k].getIconWidth() >= 1250)
				{
					lastCollide[k] = RIGHT;
				}
				else if (cometY[k] <= 0)
				{
					lastCollide[k] = UP;
				}
				else if (cometY[k] + comet[k].getIconHeight() >= 703)
				{
					lastCollide[k] = DOWN;
				}
				
				
				//moves the comet depending on the last side that the comet hit 
				if (lastCollide[k] == UP)
				{
					cometY[k] += 30;
				}
				else if (lastCollide[k] == DOWN)
				{
					cometY[k] -= 30;
				}
				else if (lastCollide[k] == RIGHT)
				{
					cometX[k] -= 30;
				}
				else if (lastCollide[k] == LEFT)
				{
					cometX[k] += 30;
				}
				
				//if the comet hits the ship, the comet respawns to a random spot in the room and hit counter is increased by 1
				if (cometMask[k].intersects(shipMask))
				{
					cometX[k] = rnd.nextInt(1250);
					cometY[k] = rnd.nextInt(703);
					hitCounter += 1;
				}
				
				//if a bullet hits a comet, the comet will respawn to a new spot in the room and the bullet is destroyed
				if (cometMask[k].intersects(bulletMask))
				{
					cometX[k] = rnd.nextInt(1250);
					cometY[k] = rnd.nextInt(703);
					
					spawn = false;
					bulletTimer.stop();
					
					bulletMask = new Rectangle2D.Double(-200, -200, 0,0);
					score += 100;
					
				}
				
				//moves the comet mask to where the comet is in the room
				cometMask[k] = new Ellipse2D.Double(cometX[k] + 20, cometY[k] + 20, comet[k].getIconWidth() - 40, comet[k].getIconHeight() - 40);

			}
		
		}
		
	
		//advance to the next room
		if (e.getSource() == roomAdvance)
		{
			room ++;
			repaint();
			
			//stops the room advance timer when room is 4
			if (room == 4)
			{
				roomAdvance.stop();
			}
			
			//stops the room advance timer again when room is 8 and starts all necessary game timers
			if (room == 8)
			{
				roomAdvance.stop();
		
				asteroidSpawner.start();
				gameEnd.start();
				asteroidTimer.start();
				asteroidTimer2.start();
				asteroidTimer3.start();
				asteroidTimer4.start();
				asteroidTimer5.start();

			}
		}
		
		//moves the bullet and the bullet mask and destroys it if it reaches the borders
		if (e.getSource() == bulletTimer)
		{
			bulletMask = new Rectangle2D.Double(bullet.getX(), bullet.getY(), bullet.getImage().getIconWidth(), bullet.getImage().getIconHeight());
			bullet.move(bulletDirection);
		
			//if the bullet is spawned and it hits the border, it is destroyed
			if (spawn == true)
			{
				if (bullet.getX() > getWidth()|| bullet.getX() < 0 || bullet.getY() > getHeight() ||bullet.getY() < 0)
				{
					bulletTimer.stop();
					spawn = false;
				}
			}
			
			//if the bullet hits the asteroid, destroy the asteroid and the bullet, and increase the score by 100
			if (asteroidMask.intersects(bulletMask))
			{
				asteroidTimer.stop();

				explosionTimer.start();
				collide = TRUE;

				spawn = false;
				bulletTimer.stop();
				bulletMask = new Rectangle2D.Double(-200, -200, 0,0);
				
				asteroid1State = NOTSPAWNED;
				score += 100;

			}
			
			//if the bullet hits the asteroid, destroy the asteroid and the bullet, and increase the score by 100
			if (asteroidMask2.intersects(bulletMask))
			{
				asteroidTimer2.stop();

				explosionTimer2.start();
				collide2 = TRUE;

				spawn = false;
				bulletTimer.stop();

				bulletMask = new Rectangle2D.Double(-200, -200, 0,0);

				asteroid2State = NOTSPAWNED;
				score += 100;

			}
			
			//if the bullet hits the asteroid, destroy the asteroid and the bullet, and increase the score by 100
			if (asteroidMask3.intersects(bulletMask))
			{
				asteroidTimer3.stop();

				explosionTimer3.start();
				collide3 = TRUE;

				spawn = false;
				bulletTimer.stop();

				bulletMask = new Rectangle2D.Double(-200, -200, 0,0);

				asteroid3State = NOTSPAWNED;
				score += 100;

			}
			
			//if the bullet hits the asteroid, destroy the asteroid and the bullet, and increase the score by 100
			if (asteroidMask4.intersects(bulletMask))
			{
				asteroidTimer4.stop();
				explosionTimer4.start();
				collide4 = TRUE;

				spawn = false;
				bulletTimer.stop();

				bulletMask = new Rectangle2D.Double(-200, -200, 0,0);

				asteroid4State = NOTSPAWNED;
				score += 100;

			}
			
			//if the bullet hits the asteroid, destroy the asteroid and the bullet, and increase the score by 100
			if (asteroidMask5.intersects(bulletMask))
			{
				asteroidTimer5.stop();
				explosionTimer5.start();
				collide5 = TRUE;

				spawn = false;
				bulletTimer.stop();

				bulletMask = new Rectangle2D.Double(-200, -200, 0,0);

				asteroid5State = NOTSPAWNED;
				score += 100;

			}
		}
		
		//moves the asteroid and the asteroid mask 
		if (e.getSource() == asteroidTimer)
		{
			asteroid.move(ship.getX(), ship.getY());
			asteroidMask = new Ellipse2D.Double(asteroid.getX() + 15, asteroid.getY() + 10, asteroid.getWidth() - 40, asteroid.getHeight() - 40);
			
			//if the asteroid hits the ship, destroy the asteroid, show and explosion and increase the hit counter by 1
			if (asteroidMask.intersects(shipMask))
			{
				asteroidTimer.stop();
				explosionTimer.start();
				collide = TRUE;
				asteroid1State = NOTSPAWNED;
				hitCounter += 1;

				
			}
		}
		
		//moves the asteroid and the asteroid mask 
		if (e.getSource() == asteroidTimer2)
		{
			asteroid2.move(ship.getX(), ship.getY());
			asteroidMask2 = new Ellipse2D.Double(asteroid2.getX() + 15, asteroid2.getY() + 10, asteroid2.getWidth() - 40, asteroid2.getHeight() - 40);
			
			//if the asteroid hits the ship, destroy the asteroid, show and explosion and increase the hit counter by 1
			if (asteroidMask2.intersects(shipMask))
			{
				asteroidTimer2.stop();
				explosionTimer2.start();
				collide2 = TRUE;
				asteroid2State = NOTSPAWNED;
				hitCounter += 1;


			}
		}
		
		//moves the asteroid and the asteroid mask 
		if (e.getSource() == asteroidTimer3)
		{
			asteroid3.move(ship.getX(), ship.getY());
			asteroidMask3 = new Ellipse2D.Double(asteroid3.getX() + 15, asteroid3.getY() + 10, asteroid3.getWidth() - 40, asteroid3.getHeight() - 40);
			
			//if the asteroid hits the ship, destroy the asteroid, show and explosion and increase the hit counter by 1
			if (asteroidMask3.intersects(shipMask))
			{
				asteroidTimer3.stop();
				explosionTimer3.start();
				collide3 = TRUE;
				asteroid3State = NOTSPAWNED;
				hitCounter += 1;
			}
		}
		
		//moves the asteroid and the asteroid mask 
		if (e.getSource() == asteroidTimer4)
		{
			asteroid4.move(ship.getX(), ship.getY());
			asteroidMask4 = new Ellipse2D.Double(asteroid4.getX() + 15, asteroid4.getY() + 10, asteroid4.getWidth() - 40, asteroid4.getHeight() - 40);
			
			//if the asteroid hits the ship, destroy the asteroid, show and explosion and increase the hit counter by 1
			if (asteroidMask4.intersects(shipMask))
			{
				asteroidTimer4.stop();
				explosionTimer4.start();
				collide4 = TRUE;
				asteroid4State = NOTSPAWNED;
				hitCounter += 1;
			}
		}
		
		//moves the asteroid and the asteroid mask 
		if (e.getSource() == asteroidTimer5)
		{
			asteroid5.move(ship.getX(), ship.getY());
			asteroidMask5 = new Ellipse2D.Double(asteroid5.getX() + 15, asteroid5.getY() + 10, asteroid5.getWidth() - 40, asteroid5.getHeight() - 40);
			
			//if the asteroid hits the ship, destroy the asteroid, show and explosion and increase the hit counter by 1
			if (asteroidMask5.intersects(shipMask))
			{
				asteroidTimer5.stop();
				explosionTimer5.start();

				collide5 = TRUE;
				asteroid5State = NOTSPAWNED;
				hitCounter += 1;

			}
		}
		
		//sets asteroid collide to false, moves the asteroid mask out the room and stops the explosion timer
		if (e.getSource() == explosionTimer)
		{
			collide = FALSE;
			explosionTimer.stop();
			asteroidMask = new Ellipse2D.Double(-100,-100,0,0);
			

		}
		
		//sets asteroid collide to false, moves the asteroid mask out the room and stops the explosion timer
		if (e.getSource() == explosionTimer2)
		{
			collide2 = FALSE;
			explosionTimer2.stop();
			asteroidMask2 = new Ellipse2D.Double(-100,-100,0,0);


		}
		
		//sets asteroid collide to false, moves the asteroid mask out the room and stops the explosion timer
		if (e.getSource() == explosionTimer3)
		{
			collide3 = FALSE;
			asteroidMask3 = new Ellipse2D.Double(-100,-100,0,0);
			explosionTimer3.stop();


		}
		
		//sets asteroid collide to false, moves the asteroid mask out the room and stops the explosion timer
		if (e.getSource() == explosionTimer4)
		{
			collide4 = FALSE;
			explosionTimer4.stop();
			asteroidMask4 = new Ellipse2D.Double(-100,-100,0,0);


		}
		
		//sets asteroid collide to false, moves the asteroid mask out the room and stops the explosion timer
		if (e.getSource() == explosionTimer5)
		{
			collide5 = FALSE;
			explosionTimer5.stop();
			asteroidMask5 = new Ellipse2D.Double(-100,-100,0,0);

		}
		
		//lets the user take in the background and sets the mood
		if (e.getSource() == intermission)
		{
			//stops the intermission timer after one iteration
			intermission.stop();
			
			//if the room is 5, it shows messages from Houston
			if (room == 5)
			{

				//asks the user for his or her name
				do
				{
					//stops the transition
					transition1.stop();

					try 
					{
						name = (String) JOptionPane.showInputDialog(null, "Oi, You There! You must be the new recruit that they mentioned.\nYou do look a little underprepared. Anyways, I am the head of Mission Control, you are to address me as Houston. What may your name be?", "Rookie Introduction", JOptionPane.PLAIN_MESSAGE, imgHouston, null, null);
						
						//prompts the user again for a name if answer is null
						if (name == "" || name == null || name == " ")
						{
							JOptionPane.showMessageDialog(null, "Oi, do not ignore my question! Please tell me your name!", "Your Name", JOptionPane.PLAIN_MESSAGE, imgHouston);
							continue;
						}
						
						//breaks loop when an answer is given
						else 
						{
							beacon.getName(name);
							break;
						}
						
					}
					//catches any exceptions
					catch (Exception exception)
					{
						JOptionPane.showMessageDialog(null, "Try to enter in another name..", "Your Name", JOptionPane.PLAIN_MESSAGE, imgHouston);
					}
					
				}
				while (1 != 2);


				//displays the message prompt to progress the story
				JOptionPane.showMessageDialog(null, "Well then " + name + ", your first mission here is to go and activate all of the beacons around the spacestation.\nThe beacons will activate our new state of the art radar system. Good Luck Buddy!\n Oh and did I mention that they designers of beacons are big fans of Harry Potter. They thought it would be a good idea to use riddles in place of password, just like the Ravenclaws.\nLet's see how good your problem-solving skills are! ", "First Mission", JOptionPane.PLAIN_MESSAGE, imgHouston);
				room ++;
				JOptionPane.showMessageDialog(null, "Alright, it says here that to active a beacon, I have to go up to it and solve a riddle.\nThat sounds easy enougth. But that is easier said than done.", "Your Thoughts", JOptionPane.PLAIN_MESSAGE, imgYou);
				roomEvent();
			}
			
			//when the room is 7, there is another cutscene to progress the story
			if (room == 7)
			{
				transition1.stop();
				JOptionPane.showMessageDialog(null, "*You walk into the International Space Station to find that nobody is here.*\n\nHmm... I wonder where everyone is. Let's check the command centre.\nWhat's this?\nTHERE ARE OVER 50 000 ASTEROIDS HEADED FOR EARTH\nWait there is a note here.", "Deserted", JOptionPane.PLAIN_MESSAGE, imgYou);
				JOptionPane.showMessageDialog(null, "Houston here, " + name + " sorry we had to leave. By the time you read this, we will all be on Earth.\nThis means that you are our only hope.\nThe spaceship you have been using the whole time has a railgun, press the \"s\" key to fire.\nNow get out there and make us proud!", "Deserted", JOptionPane.PLAIN_MESSAGE, imgHouston);
				
				room ++;
				gameEnd.start();


			}
			
			//Provides the initial instructions on how to beat the wave
			if (room == 8)
			{
				JOptionPane.showMessageDialog(null, "Shoot the astroids that come towards you and try to avoid being hit.\nI must warn you, these asteroids chase after you and can fuse together to form 1 asteroid that requires multiple shots to destroy.\nShoot 10 asteroids to complete the wave", "Instructions", JOptionPane.PLAIN_MESSAGE, imgHouston);
				asteroidSpawner.start();
			}
			
			//displays the congratulation messages
			if (room == 10)
			{
				JOptionPane.showMessageDialog(null, "Well done " + name + ", you actually did it! You stopped the wave of asteroids from hitting Earth\nGood on you! Well I must say that you have certainly impressed me\nI know your are still a inexperienced rookie but what do you say to a promotion?\nI think that you'll be a great janitor! HA HA HA!\nJust messing with you!", "Promotion?", JOptionPane.PLAIN_MESSAGE, imgHouston);
				JOptionPane.showMessageDialog(null, "Congratulations " + name + ", you beat the game", "WINNER", JOptionPane.PLAIN_MESSAGE, imgHouston);
				room = 2;
				roomAdvance.start();

			}
		}
		
		
		//checks to see if each asteroid is spawned in, if not, then they are spawned in outside the borders of the room and their corresponding timer is started
		if (e.getSource() == asteroidSpawner)
		{
	
			
			if (asteroid1State == NOTSPAWNED)
			{	
				asteroid.spawn();
				asteroid1State = SPAWNED;
				asteroidTimer.start();
			}
			
			if (asteroid2State == NOTSPAWNED)
			{
				asteroid2.spawn();
				asteroid2State = SPAWNED;
				asteroidTimer2.start();
			}
			
			if (asteroid3State == NOTSPAWNED)
			{
				asteroid3.spawn();
				asteroid3State = SPAWNED;
				asteroidTimer3.start();

			}
			
			if (asteroid4State == NOTSPAWNED)
			{
				asteroid4.spawn();
				asteroid4State = SPAWNED;
				asteroidTimer4.start();

			}
		
			if (asteroid5State == NOTSPAWNED)
			{
				asteroid5.spawn();
				asteroid5State = SPAWNED;
				asteroidTimer5.start();

			}

		}
		
		//moves the ship for the cutscene
		if (e.getSource() == transition1)
		{
			transition1X += 10;
		}
		
		

		//checks to see if the game ends
		if (e.getSource() == gameEnd)
		{
			
			if (room == 8 || room == 9)
			{
				//ends the game if the user gets hit 5 times or more
				if (hitCounter >= 5)
				{
					asteroidSpawner.stop();
					asteroidTimer.stop();
					asteroidTimer2.stop();
					asteroidTimer3.stop();
					asteroidTimer4.stop();
					asteroidTimer5.stop();
					bulletTimer.stop();
					cometTimer.stop();
					gameEnd.stop();
					JOptionPane.showMessageDialog(null, "EXPLOSION\n You broke the spaceship! Sorry, please play again!", "Game Lost", JOptionPane.PLAIN_MESSAGE, imgHouston);
					asteroidSpawner.stop();
					asteroidTimer.stop();
					asteroidTimer2.stop();
					asteroidTimer3.stop();
					asteroidTimer4.stop();
					asteroidTimer5.stop();
					bulletTimer.stop();
					gameEnd.stop();
					room = 2;
					roomAdvance.start();
				}
				
				//goes to the next room if the user gets the necessary score
				//stops all game timer and shows a message from Houston to progress the story
				if (room == 8)
				{
					if (score >= 1000)
					{
						asteroidSpawner.stop();
						asteroidTimer.stop();
						asteroidTimer2.stop();
						asteroidTimer3.stop();
						asteroidTimer4.stop();
						asteroidTimer5.stop();
						bulletTimer.stop();
						gameEnd.stop();
						
						//message pane to progress the story
						JOptionPane.showMessageDialog(null, "Congratulations, you managed to beat back the wave of asteroids!\nThis calls for celebration\n...\nWAIT!  THERE ARE MORE!\nGet ready " + name + " we are getting readings of comets on the radar that you activated\nThese comets are not regular comets, they are fast but don't chase you. Also, they cannot be destroyed, when you shoot at them, the teleport to a new spot in the room so be careful!", "Wave Beaten", JOptionPane.PLAIN_MESSAGE, imgHouston);
						
						//restarts all the game timers for the next room
						room ++;
						score = 0;
						cometTimer.start();
						gameEnd.start();
						asteroidSpawner.start();
						asteroidTimer.start();
						asteroidTimer2.start();
						asteroidTimer3.start();
						asteroidTimer4.start();
						asteroidTimer5.start();
						
					}
				}
				
				if (room == 9)
				{
					//ends the game if the user gets the necessary score
					//stops all game timers and displays a winner message
					if (score >= 2000)
					{
						asteroidSpawner.stop();
						asteroidTimer.stop();
						asteroidTimer2.stop();
						asteroidTimer3.stop();
						asteroidTimer4.stop();
						asteroidTimer5.stop();
						bulletTimer.stop();
						cometTimer.stop();
						gameEnd.stop();
						
						//tells the player that they won
						JOptionPane.showMessageDialog(null, "Congratulations, you managed to beat back the final wave of asteroids!", "Game Won", JOptionPane.PLAIN_MESSAGE, imgHouston);
						room += 1;
						intermission.start();
					}
				}
			}
			
			
			
		}

		repaint();
	}
	
	public void roomEvent()
	{
		//draws all 4 beacon masks
		if (room == 6)
		{
			beacon1Mask = new Rectangle2D.Double(100, 100, beacon.getWidth(), beacon.getHeight());
			beacon2Mask = new Rectangle2D.Double(800, 100, beacon.getWidth(), beacon.getHeight());
			beacon3Mask = new Rectangle2D.Double(100, 500, beacon.getWidth(), beacon.getHeight());
			beacon4Mask = new Rectangle2D.Double(800, 500, beacon.getWidth(), beacon.getHeight());	
			transition1.start();
		}
		
		//starts intermission and transition timer when room is 7
		if (room == 7)
		{
			intermission.start();
			transition1.start();
		}
		
		//repaints updated images
		repaint();
		
	}
	
	//empty methods
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	
	//if the player is on the start page, check if any of the buttons are clicked
	public void mouseClicked(MouseEvent e)
	{
		if (room == 4)
		{
			//if the user clicks on the start button, advance to the next room
			if (e.getX() >= 300 && e.getX() <= 300 + startButton.getIconWidth() && e.getY() >= 600 && e.getY() <= 600 + startButton.getIconHeight())
			{
				room ++;
				transition1.start();
				intermission.start();
			}
			
			//if the user clicks on the help button, display a message pane with instructions
			if (e.getX() >= 800 && e.getX() <= 800 + startButton.getIconWidth() && e.getY() >= 600 && e.getY() <= 600 + startButton.getIconHeight())
			{
				JOptionPane.showMessageDialog(null, "So you want to know how to play the game? Well, it is quite simple.\nThe aim of the game is to follow the directions of Mission Control.\nYou will only need to use the 4 arrow keys along with the \"s\" key to shoot.\nSimply do as the instructions say and you will be fine", "HOW TO PLAY?", JOptionPane.PLAIN_MESSAGE, null);
			}
		}
	
		//repaints updated graphics
		repaint();
	}
	
	
	//paint method paints all graphical components of the game
	public void paint (Graphics g)
	{
		//setup graphics2D
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;
		
		//In the first room, show the puzzle
		if (room == 1)
		{
			frame.setSize(puzzle.getIconWidth(), puzzle.getIconHeight());
			g2.drawImage(puzzle.getImage(), 0,0, this);
		}
		//display the loading page for the second room
		if (room == 2)
		{
			frame.setSize(loadingPage.getIconWidth(), loadingPage.getIconHeight());
			g2.drawImage(loadingPage.getImage(), 0, 0, this);

		}
		
		//display the game poster in the third room
		else if (room == 3)
		{
			frame.setSize(title.getIconWidth(), title.getIconHeight());
			g2.drawImage(title.getImage(),0,0, this);
		}
		
		
		//display the start page with clickable buttons in the fourth page 
		else if (room == 4)
		{
			frame.setSize(startPage.getIconWidth(), startPage.getIconHeight());
			g2.drawImage(startPage.getImage(), 0, 0, this);
			
			g2.drawImage(startButton.getImage(), 300, 600, this);
			g2.drawImage(helpButton.getImage(), 800, 600, this);
			
			Font f = new Font ("Tahoma", Font.BOLD, 56);
			g2.setColor(Color.blue);
			g2.setFont(f);
			g2.drawString("INTERSTELLAR  ASSAULT", getWidth() / 2 - 300, getHeight() /2);
		
		}
		
		//show the intermission
		else if (room == 5)
		{
			frame.setSize(cutscene1.getIconWidth(), cutscene1.getIconHeight());
			g2.drawImage(cutscene1.getImage(), 0,0, this);
			g2.drawImage(imgTransition1.getImage(), transition1X, 350, this);
		}
		
		
		//draw the room with the beacons as well as the ship
		else if (room == 6)
		{
			frame.setSize(1250, 703);
			g2.drawImage(background.getImage(),0,0, this);
			g2.drawImage(beacon.getImage(0).getImage(), 100, 100, this);
			g2.drawImage(beacon.getImage(1).getImage(), 800, 100, this);
			g2.drawImage(beacon.getImage(2).getImage(), 100, 500, this);
			g2.drawImage(beacon.getImage(3).getImage(), 800, 500, this);
			g2.drawImage(ship.getImage(direction).getImage(), ship.getX(), ship.getY(), this);

			roomEvent();
		}
		
		//shows the intermission cutscene again
		else if (room == 7)
		{
			frame.setSize(cutscene1.getIconWidth(), cutscene1.getIconHeight());
			g2.drawImage(cutscene1.getImage(), 0,0, this);	
			g2.drawImage(imgTransition1.getImage(), transition1X, 350, this);
		}
		
		
		//if it is room 8, draw the asteroids and the ship
		else if (room == 8 || room == 9)
		{
			frame.setSize(1250, 703);
			
			g2.drawImage(background.getImage(),0,0, this);
			
			g2.setColor(Color.red);
			//g2.fill(cometMask[1]);
			
			
			//if the room is room 8, draw everything in room 7, except this time, there will be comets in the game as well
			if (room > 8)
			for (int j = 0; j < 10; j ++)
			{
				g2.drawImage(comet[j].getImage(), cometX[j], cometY[j], this);
			}
			
			//draw the image of the ship
			g2.drawImage(ship.getImage(direction).getImage(), ship.getX(), ship.getY(), this);
			
			//if the asteroid does not hit anything and it is spawned in, draw the asteroid
			if (collide == FALSE && asteroid1State == SPAWNED)
			{
				g2.drawImage(asteroid.getImage().getImage(), asteroid.getX(), asteroid.getY(), this);
					
			}
			
			//when it hits something, display an explosion
			else if (collide == TRUE)
			{
				g2.drawImage(asteroid.explosion().getImage(), asteroid.getX(), asteroid.getY(), this);
			}
		
			//if the asteroid does not hit anything and it is spawned in, draw the asteroid
			if (collide2 == FALSE && asteroid2State == SPAWNED)
			{
				g2.drawImage(asteroid2.getImage().getImage(), asteroid2.getX(), asteroid2.getY(), this);
					
			}
			
			//when it hits something, display an explosion
			else if (collide2 == TRUE)
			{
				g2.drawImage(asteroid2.explosion().getImage(), asteroid2.getX(), asteroid2.getY(), this);
			}
			
			//if the asteroid does not hit anything and it is spawned in, draw the asteroid
			if (collide3 == FALSE && asteroid3State == SPAWNED)
			{
				g2.drawImage(asteroid3.getImage().getImage(), asteroid3.getX(), asteroid3.getY(), this);
					
			}
			
			//when it hits something, display an explosion
			else if (collide3 == TRUE)
			{
				g2.drawImage(asteroid3.explosion().getImage(), asteroid3.getX(), asteroid3.getY(), this);
			}
			
			//if the asteroid does not hit anything and it is spawned in, draw the asteroid
			if (collide4 == FALSE && asteroid4State == SPAWNED)
			{
				g2.drawImage(asteroid4.getImage().getImage(), asteroid4.getX(), asteroid4.getY(), this);
					
			}
			
			//when it hits something, display an explosion
			else if (collide4 == TRUE)
			{
				g2.drawImage(asteroid4.explosion().getImage(), asteroid4.getX(), asteroid4.getY(), this);
			}
			
			//if the asteroid does not hit anything and it is spawned in, draw the asteroid
			if (collide5 == FALSE && asteroid5State == SPAWNED)
			{
				g2.drawImage(asteroid5.getImage().getImage(), asteroid5.getX(), asteroid5.getY(), this);
					
			}
			
			//when it hits something, display an explosion
			else if (collide5 == TRUE)
			{
				g2.drawImage(asteroid5.explosion().getImage(), asteroid5.getX(), asteroid5.getY(), this);
			}
		
		
			//when bullet spawn is true, draw the bullet
			if (spawn == true)
			{
				g2.drawImage(bullet.getImage().getImage(), bullet.getX() , bullet.getY(), this);
			}
		}
		
		//draw the cutscene for room 10
		else if (room == 10)
		{
			frame.setSize(cutscene1.getIconWidth(), cutscene1.getIconHeight());
			g2.drawImage(cutscene1.getImage(), 0,0, this);	

			
		}
	}
}
