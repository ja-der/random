//import classes
import javax.swing.*;

public class Beacon {
	
	//declare variables
	private int x, y;
	private ImageIcon imgBeacon, imgBeaconUp, imgQuestioner, beaconImages [];
	private int beacon [], counter;
	private final int DOWN = 1, UP = 2;
	private String playerName, question, answer, guess;
	private boolean win;

	
	public Beacon ()
	{
		
		//initialize varaiables
		x = 100;
		y = 100;
		imgBeacon = new ImageIcon("beaconDown.png");
		imgBeaconUp = new ImageIcon("beacon.jfif");
		imgQuestioner = new ImageIcon("questioner.png");
		beacon  = new int [4];
		beaconImages = new ImageIcon [4];
		win = false;
		counter = 0;
		question = "";
		answer = "";
		guess = "";
		
		//fill in elements for beacon arrays
		for (int i = 0; i < 4; i ++)
		{
			beacon [i] = DOWN;
			beaconImages [i] = imgBeacon;
		}
	}
	
	//gets the player name
	public void getName(String name)
	{
		playerName = name;
	}
	
	//chooses question depending on which beacon that the player intersected with
	public void question(int number)
	{
		if (beacon[number] == DOWN)
		{
			if (number == 0)
			{
				question = "First think of the person who lives in disguise, Who deals in secrets and tells naught but lies.\nNext, tell me what's always the last thing to mend, The middle of the middle and end of the end?\nAnd finally, give me the sound often heard During the search for a hard-to-find word.\nWhat am I?";
				answer = "spider";
			}

			if (number == 1)
			{
				question = "Who is that with a neck and no head, two arms and no hands?";
				answer = "shirt";
			}
			
			if (number == 2)
			{
				question = "What English word retains the same pronunciation, even after you take away four of its five letters?";
				answer = "queue";
			}
			
			if (number == 3)
			{
				question = "What is it that given one, you'll have either two or none";
				answer = "choice";
			}
			
			
			//asks the user for their answer
			do
			{
				try
				{
					guess = (String) JOptionPane.showInputDialog(null, question, "Riddle Password", JOptionPane.PLAIN_MESSAGE, imgQuestioner, null, null);
					
		
					//if the answer is correct, the beacon is activated and the image icon changes
					if (guess.equalsIgnoreCase(answer))
					{
						JOptionPane.showMessageDialog(null, "Congratulations " + playerName + ", that is correct! ", "Beacon Activated", JOptionPane.PLAIN_MESSAGE, imgQuestioner);
						beacon[number] = UP;
						beaconImages[number] = imgBeaconUp;
						break;

					}
					
					//if the answer is wrong, the user has to try again
					else 
					{
						JOptionPane.showMessageDialog(null, "Sorry " + playerName + ", that is incorrect! Please try Again! ", "Beacon Not Activated", JOptionPane.PLAIN_MESSAGE, imgQuestioner);
					}
				}
				
				//catches exceptions
				catch (Exception e)
				{
					JOptionPane.showMessageDialog(null, "Unfortunately, you cannot leave unless you solve the riddle!\n Once you enter, you cannot return! ", "Point Of No Return", JOptionPane.PLAIN_MESSAGE, imgQuestioner);

				}
			}
			while(1 != 2);
			
			//checks to see if all beacons are activated
			for (int k = 0; k < 4; k ++)
			{
				//if beacon is up, add one to the counter
				if (beacon[k] == UP)
				{
					counter += 1;
				}
				
				//if all beacons are activated, the player won the quiz mini-game
				if (counter == 10)
				{
					win = true;
				}
			}
			
		}
			
	}
	
	public ImageIcon getImage(int number)
	{		
		return beaconImages[number];
	}
	
	
	public int getWidth()
	{
		return imgBeacon.getIconWidth();
	}
	
	public int getHeight()
	{
		return imgBeacon.getIconHeight();
	}
	
	public boolean win()
	{
		return win;
	}

	
	
}

