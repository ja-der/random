//import classes
import javax.swing.*;

public class Bullet {
	
	//declare variables
	final public int LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4, panelHeight = 1000, panelWidth = 1000;
	private int xPos, yPos;
	private ImageIcon imgBullet;
	
	//create object pointing to spaceship class
	Spaceship ship = new Spaceship();
	
	
	public Bullet ()
	{
		//initialize variables
		Spaceship ship = new Spaceship();
		imgBullet = new ImageIcon("bullet.png");
		yPos = 0;
		xPos = 0;
	}
	
	//returns the x position of the bullet
	public int getX()
	{
		return xPos;
	}
	
	//returns the y position of the bullet
	public int getY()
	{
		return yPos;
	}
	
	//puts the bullet at its initial position
	public void spawnY(int initialY)
	{
		yPos = initialY;
	}
	
	//puts the bullet at its initial position

	public void spawnX(int initialX)
	{
		xPos = initialX;
	}
	
	
	public void move(int direction)
	{
	
		//moves the bullet depending on the direction of the ship when the bullet was fired
		if (direction == UP)
		{
			yPos -= 30;
		}
		else if (direction == DOWN)
		{
			yPos += 30;
		}
		else if (direction == RIGHT)
		{
			xPos += 30;
		}
		else if (direction == LEFT)
		{
			xPos -= 30;
		}
	}
	
	//returns the image icon of the bullet
	public ImageIcon getImage()
	{
		return imgBullet;
	}
	
	
	
	


}
